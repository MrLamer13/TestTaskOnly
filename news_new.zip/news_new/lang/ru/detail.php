<?
$MESS ['T_NEWS_DETAIL_BACK'] = "Назад к новостям";
$MESS ['CATEGORIES'] = "Материалы по теме:";
?>