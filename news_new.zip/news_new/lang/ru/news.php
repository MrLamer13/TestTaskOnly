<?
$MESS ['SEARCH_LABEL'] = "Поиск:";
?>
